export interface ChurchBranch {
  id: string; // e.g. "FSQ-3A5HE6"
  orgCode: string; // "FSQ-3A5HE6"
  name: string; // "Grace Chapel - West District"
  parentOrgId: string; // "parent-foursquare"
  parentOrgName: string; // "Foursquare Gospel Fellowship"
  location: string; // "Seattle, WA"
  sanctuaryCapacity: number; // 450
  defaultAspectRatio: "16:9" | "16:10" | "4:3" | "ULTRAWIDE";
  adminName: string; // "Pastor Mark Stevens"
  adminEmail: string; // "admin@gracechapel.org"
  passwordHash: string; // demo plain or hashed
  createdAt: string;
  verified: boolean;
  status: "ACTIVE" | "PENDING_APPROVAL" | "SUSPENDED";
  storageUsedMb: number;
  maxStorageMb: number;
}

export interface ParentOrganization {
  id: string; // "parent-foursquare"
  name: string; // "Foursquare Gospel Fellowship"
  shortCode: string; // "FSQ"
  logoIcon: string;
  totalBranches: number;
  contactEmail: string;
}

export interface SlideItem {
  id: string;
  type: "TITLE" | "SCRIPTURE" | "HYMN_VERSE" | "LOWER_THIRD" | "ANNOUNCEMENT" | "VIDEO_BG";
  title: string;
  subtitle?: string;
  bodyText?: string;
  scriptureReference?: string;
  bgMediaUrl?: string;
  bgColor?: string;
  textColor?: string;
  alignment: "center" | "left" | "right";
  notes?: string;
}

export interface PresentationDeck {
  id: string;
  branchId: string; // Tenant isolation key
  title: string; // e.g., "Sunday Service - Walking in Grace"
  category: "SUNDAY_WORSHIP" | "MIDWEEK_STUDY" | "YOUTH_NIGHT" | "SPECIAL_EVENT";
  date: string;
  slides: SlideItem[];
  aspectRatio: "16:9" | "16:10" | "4:3";
  isLive?: boolean;
  lastEditedBy: string;
}

export interface MediaAsset {
  id: string;
  branchId: string; // Tenant isolation key
  name: string;
  type: "MOTION_BACKGROUND" | "SERMON_SERIES" | "LOWER_THIRD" | "AUDIO_STEM";
  url: string;
  thumbnailUrl: string;
  fileSizeMb: number;
  uploadedAt: string;
  uploadedBy: string;
  tags: string[];
}

export interface TeamMember {
  id: string;
  branchId: string; // Tenant isolation key
  name: string;
  email: string;
  role: "BRANCH_ADMIN" | "WORSHIP_DIRECTOR" | "MEDIA_OPERATOR" | "VOLUNTEER";
  avatarUrl?: string;
  status: "ACTIVE" | "INVITED";
  joinedDate: string;
}

export interface SecurityAuditLog {
  id: string;
  branchId: string;
  timestamp: string;
  event: string;
  actorEmail: string;
  ipAddress: string;
  status: "SUCCESS" | "WARNING" | "BLOCKED";
}

export interface UserSession {
  branch: ChurchBranch;
  userEmail: string;
  userName: string;
  role: "BRANCH_ADMIN" | "WORSHIP_DIRECTOR" | "MEDIA_OPERATOR" | "VOLUNTEER";
  token: string;
}
