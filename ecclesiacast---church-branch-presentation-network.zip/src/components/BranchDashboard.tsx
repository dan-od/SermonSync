import React, { useState } from 'react';
import { 
  Tv, 
  Layers, 
  Film, 
  Users, 
  ShieldCheck, 
  Settings, 
  LogOut, 
  Plus, 
  Play, 
  Search, 
  Upload, 
  Building2, 
  Sparkles, 
  HardDrive, 
  CheckCircle2, 
  Lock, 
  Clock, 
  Trash2, 
  Copy, 
  ExternalLink, 
  Radio, 
  ChevronRight, 
  BookOpen, 
  Music, 
  Layout, 
  Monitor, 
  Shield, 
  UserPlus, 
  AlertTriangle,
  Tag
} from 'lucide-react';
import { UserSession, PresentationDeck, MediaAsset, TeamMember, SecurityAuditLog } from '../types';
import { OrgCodeBadge } from './OrgCodeBadge';
import { LivePresenterModal } from './LivePresenterModal';
import { NewDeckModal } from './NewDeckModal';
import { MediaUploadModal } from './MediaUploadModal';

interface BranchDashboardProps {
  session: UserSession;
  decks: PresentationDeck[];
  mediaList: MediaAsset[];
  teamMembers: TeamMember[];
  auditLogs: SecurityAuditLog[];
  onLogout: () => void;
  onCreateDeck: (deck: PresentationDeck) => void;
  onDeleteDeck: (deckId: string) => void;
  onUploadMedia: (asset: MediaAsset) => void;
  onDeleteMedia: (mediaId: string) => void;
  onAddTeamMember: (member: TeamMember) => void;
}

export const BranchDashboard: React.FC<BranchDashboardProps> = ({
  session,
  decks,
  mediaList,
  teamMembers,
  auditLogs,
  onLogout,
  onCreateDeck,
  onDeleteDeck,
  onUploadMedia,
  onDeleteMedia,
  onAddTeamMember,
}) => {
  const [activeTab, setActiveTab] = useState<'DECKS' | 'MEDIA' | 'TEAM' | 'SECURITY' | 'SETTINGS'>('DECKS');

  // Modals state
  const [activeLiveDeck, setActiveLiveDeck] = useState<PresentationDeck | null>(null);
  const [showNewDeckModal, setShowNewDeckModal] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);

  // Search & Filter state
  const [deckSearch, setDeckSearch] = useState('');
  const [mediaSearch, setMediaSearch] = useState('');

  // New Team Member State
  const [showAddTeamModal, setShowAddTeamModal] = useState(false);
  const [newTeamName, setNewTeamName] = useState('');
  const [newTeamEmail, setNewTeamEmail] = useState('');
  const [newTeamRole, setNewTeamRole] = useState<TeamMember['role']>('MEDIA_OPERATOR');

  // Calculate storage percentage
  const storagePercent = Math.min(
    100,
    Math.round((session.branch.storageUsedMb / session.branch.maxStorageMb) * 100)
  );

  const filteredDecks = decks.filter((d) =>
    d.title.toLowerCase().includes(deckSearch.toLowerCase()) ||
    d.category.toLowerCase().includes(deckSearch.toLowerCase())
  );

  const filteredMedia = mediaList.filter((m) =>
    m.name.toLowerCase().includes(mediaSearch.toLowerCase()) ||
    m.tags.some((t) => t.toLowerCase().includes(mediaSearch.toLowerCase()))
  );

  const handleAddTeamSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTeamName || !newTeamEmail) return;

    const newMember: TeamMember = {
      id: `tm-${session.branch.id}-${Date.now()}`,
      branchId: session.branch.id,
      name: newTeamName,
      email: newTeamEmail,
      role: newTeamRole,
      status: 'ACTIVE',
      joinedDate: new Date().toISOString().split('T')[0],
    };

    onAddTeamMember(newMember);
    setNewTeamName('');
    setNewTeamEmail('');
    setShowAddTeamModal(false);
  };

  return (
    <div className="flex-1 bg-[#171614] text-[#EFECE6] flex flex-col font-sans selection:bg-[#C59B27] selection:text-[#171614] w-full h-full overflow-y-auto">
      
      {/* Editorial Desktop Title Bar */}
      <header className="border-b border-[#36332E]/60 px-8 py-4 flex items-center justify-between shrink-0 select-none bg-[#171614]">
        
        {/* Left Branch Title & Identity */}
        <div className="flex items-center gap-5">
          <div className="w-9 h-9 rounded bg-[#C59B27]/10 text-[#E5B842] flex items-center justify-center font-black border border-[#C59B27]/30">
            <Tv className="w-5 h-5 text-[#E5B842]" />
          </div>

          <div>
            <div className="flex items-center gap-3">
              <span className="font-serif-title font-bold text-xl text-[#FAF7F2] tracking-wide">{session.branch.name}</span>
              <OrgCodeBadge code={session.branch.orgCode} size="sm" showSecurityTag={true} />
            </div>
            <p className="text-xs text-[#A8A29E] font-serif italic mt-0.5">
              Parent Denomination: <span className="text-[#EFECE6] not-italic font-sans font-medium">{session.branch.parentOrgName}</span>
            </p>
          </div>
        </div>

        {/* Right Session Admin Controls */}
        <div className="flex items-center gap-5">
          <div className="hidden md:flex items-center gap-2 text-xs text-[#A8A29E]">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-mono text-[11px] text-[#A8A29E]">Vault Hash Verified</span>
          </div>

          <div className="h-4 w-px bg-[#36332E]" />

          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-full bg-[#C59B27]/20 text-[#E5B842] flex items-center justify-center text-xs font-serif font-bold border border-[#C59B27]/30">
              {session.userName.charAt(0)}
            </div>
            <div className="text-left hidden lg:block">
              <div className="text-xs font-serif font-bold text-[#FAF7F2] leading-none">{session.userName}</div>
              <div className="text-[10px] text-[#E5B842] font-mono uppercase tracking-wider mt-1">{session.role}</div>
            </div>
          </div>

          <button
            onClick={onLogout}
            className="p-1.5 text-[#A8A29E] hover:text-rose-400 transition-colors flex items-center gap-1 text-xs font-mono uppercase tracking-wider ml-2"
            title="Log Out of Branch Session"
          >
            <LogOut className="w-4 h-4" />
            <span className="hidden sm:inline">Log Out</span>
          </button>
        </div>
      </header>

      {/* Main Editorial Underline Tab Bar */}
      <div className="border-b border-[#36332E]/60 px-8 py-1 flex items-center justify-between overflow-x-auto gap-8 bg-[#171614]">
        <div className="flex items-center gap-8">
          <button
            onClick={() => setActiveTab('DECKS')}
            className={`py-3 text-xs font-mono uppercase tracking-widest transition-all flex items-center gap-2 border-b-2 ${
              activeTab === 'DECKS'
                ? 'border-[#C59B27] text-[#E5B842] font-bold'
                : 'border-transparent text-[#A8A29E] hover:text-[#EFECE6]'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Presentation Decks ({decks.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('MEDIA')}
            className={`py-3 text-xs font-mono uppercase tracking-widest transition-all flex items-center gap-2 border-b-2 ${
              activeTab === 'MEDIA'
                ? 'border-[#C59B27] text-[#E5B842] font-bold'
                : 'border-transparent text-[#A8A29E] hover:text-[#EFECE6]'
            }`}
          >
            <Film className="w-4 h-4" />
            <span>Media Vault ({mediaList.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('TEAM')}
            className={`py-3 text-xs font-mono uppercase tracking-widest transition-all flex items-center gap-2 border-b-2 ${
              activeTab === 'TEAM'
                ? 'border-[#C59B27] text-[#E5B842] font-bold'
                : 'border-transparent text-[#A8A29E] hover:text-[#EFECE6]'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Branch Team ({teamMembers.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('SECURITY')}
            className={`py-3 text-xs font-mono uppercase tracking-widest transition-all flex items-center gap-2 border-b-2 ${
              activeTab === 'SECURITY'
                ? 'border-[#C59B27] text-[#E5B842] font-bold'
                : 'border-transparent text-[#A8A29E] hover:text-[#EFECE6]'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Tenant Security</span>
          </button>

          <button
            onClick={() => setActiveTab('SETTINGS')}
            className={`py-3 text-xs font-mono uppercase tracking-widest transition-all flex items-center gap-2 border-b-2 ${
              activeTab === 'SETTINGS'
                ? 'border-[#C59B27] text-[#E5B842] font-bold'
                : 'border-transparent text-[#A8A29E] hover:text-[#EFECE6]'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>Branch Specs</span>
          </button>
        </div>

        {/* Storage Bar Indicator */}
        <div className="hidden lg:flex items-center gap-3 text-xs">
          <HardDrive className="w-4 h-4 text-[#C59B27]" />
          <div className="flex items-center gap-2 text-[11px] font-mono text-[#A8A29E]">
            <span>Storage: {(session.branch.storageUsedMb / 1024).toFixed(2)} / {(session.branch.maxStorageMb / 1024).toFixed(0)} GB</span>
            <div className="w-20 h-1 bg-[#2A2723] rounded-full overflow-hidden">
              <div
                className="h-full bg-[#C59B27] rounded-full"
                style={{ width: `${storagePercent}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <main className="flex-1 px-8 py-10 max-w-7xl mx-auto w-full space-y-12">
        
        {/* TAB 1: PRESENTATION DECKS */}
        {activeTab === 'DECKS' && (
          <div className="space-y-10">
            
            {/* Editorial Header Bar */}
            <div className="flex flex-col md:flex-row items-start md:items-end justify-between gap-6 border-b border-[#36332E]/60 pb-8">
              <div className="space-y-2 max-w-xl">
                <div className="text-xs font-mono uppercase tracking-widest text-[#E5B842] flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-[#E5B842] rounded-full inline-block" />
                  Sanctuary Presentation Catalogue
                </div>
                <h2 className="font-serif-title text-4xl font-bold text-[#FAF7F2] tracking-tight">
                  Presentation Decks
                </h2>
                <p className="text-sm text-[#A8A29E] font-serif italic leading-relaxed">
                  Worship lyrics, scripture verses, and sermon slides bound exclusively to branch <strong className="text-[#E5B842] font-mono not-italic">{session.branch.orgCode}</strong>.
                </p>
              </div>

              <div className="flex items-center gap-4 w-full md:w-auto">
                {/* Search */}
                <div className="relative flex-1 md:w-64">
                  <Search className="w-4 h-4 absolute left-0 top-1/2 -translate-y-1/2 text-[#A8A29E]" />
                  <input
                    type="text"
                    value={deckSearch}
                    onChange={(e) => setDeckSearch(e.target.value)}
                    placeholder="Filter catalog..."
                    className="w-full bg-transparent border-b border-[#36332E] focus:border-[#C59B27] pl-6 pr-2 py-2 text-xs text-[#EFECE6] placeholder-[#575249] focus:outline-none transition-colors font-serif"
                  />
                </div>

                <button
                  type="button"
                  onClick={() => setShowNewDeckModal(true)}
                  className="bg-[#C59B27] hover:bg-[#E5B842] text-[#171614] font-mono uppercase tracking-widest font-bold px-5 py-2.5 rounded text-xs transition-all flex items-center gap-2 shrink-0 shadow-sm"
                >
                  <Plus className="w-4 h-4" />
                  <span>Create Deck</span>
                </button>
              </div>
            </div>

            {/* Decks Magazine Editorial Layout */}
            {filteredDecks.length === 0 ? (
              <div className="py-20 text-center space-y-4 border-b border-[#36332E]/40">
                <Layers className="w-12 h-12 text-[#575249] mx-auto" />
                <h3 className="font-serif-title text-2xl font-bold text-[#FAF7F2]">No Presentation Decks Found</h3>
                <p className="text-sm text-[#A8A29E] font-serif italic max-w-md mx-auto">
                  Get started by creating a new Sunday Worship deck or scripture slide presentation for your sanctuary.
                </p>
                <button
                  onClick={() => setShowNewDeckModal(true)}
                  className="bg-[#C59B27] hover:bg-[#E5B842] text-[#171614] font-mono uppercase font-bold px-5 py-2.5 rounded text-xs inline-flex items-center gap-2 mt-2"
                >
                  <Plus className="w-4 h-4" />
                  Create First Deck
                </button>
              </div>
            ) : (
              <div className="space-y-12">
                
                {/* Featured Lead Editorial Deck Block */}
                {filteredDecks[0] && (
                  <div className="border-b-2 border-[#C59B27]/40 pb-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                    <div className="lg:col-span-8 space-y-4">
                      <div className="flex items-center gap-3 text-xs font-mono text-[#E5B842]">
                        <span className="uppercase tracking-widest font-bold px-2 py-0.5 border border-[#C59B27]/40 rounded text-[10px]">
                          FEATURED PRESENTATION
                        </span>
                        <span className="text-[#A8A29E]">•</span>
                        <span className="uppercase tracking-widest">{filteredDecks[0].category.replace('_', ' ')}</span>
                        <span className="text-[#A8A29E]">•</span>
                        <span className="text-[#A8A29E]">{filteredDecks[0].date}</span>
                      </div>

                      <h3 className="font-serif-title text-3xl sm:text-4xl font-bold text-[#FAF7F2] leading-tight hover:text-[#E5B842] transition-colors cursor-pointer" onClick={() => setActiveLiveDeck(filteredDecks[0])}>
                        {filteredDecks[0].title}
                      </h3>

                      {filteredDecks[0].slides[0] && (
                        <blockquote className="text-base text-[#D6D1C7] font-serif italic border-l-2 border-[#C59B27] pl-4 py-1 leading-relaxed">
                          "{filteredDecks[0].slides[0].bodyText || filteredDecks[0].slides[0].title}"
                        </blockquote>
                      )}

                      <div className="flex items-center gap-4 text-xs font-serif text-[#A8A29E] pt-2">
                        <span>{filteredDecks[0].slides.length} Slides in Deck</span>
                        <span>•</span>
                        <span className="font-mono text-[10px] uppercase text-[#E5B842] font-semibold">{filteredDecks[0].aspectRatio} Aspect Ratio</span>
                        <span>•</span>
                        <span className="font-mono text-[10px] text-emerald-400">Sanctuary Vault Verified</span>
                      </div>
                    </div>

                    <div className="lg:col-span-4 flex flex-col justify-between h-full pt-4 lg:pt-0 lg:border-l lg:border-[#36332E]/60 lg:pl-8 space-y-6">
                      <div className="space-y-2">
                        <div className="text-xs font-mono uppercase tracking-widest text-[#A8A29E]">Broadcast Status</div>
                        <div className="text-sm font-serif italic text-[#D6D1C7]">
                          Ready for projection on dual sanctuary displays.
                        </div>
                      </div>

                      <div className="flex items-center gap-4">
                        <button
                          type="button"
                          onClick={() => setActiveLiveDeck(filteredDecks[0])}
                          className="bg-emerald-800/90 hover:bg-emerald-700 text-white font-mono uppercase tracking-wider text-xs font-bold px-5 py-3 rounded transition-all flex items-center gap-2 shadow-md w-full justify-center"
                        >
                          <Radio className="w-4 h-4 animate-pulse text-emerald-300" />
                          <span>Launch Live Presenter</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => onDeleteDeck(filteredDecks[0].id)}
                          className="p-3 text-[#A8A29E] hover:text-rose-400 transition-colors border border-[#36332E] hover:border-rose-800/60 rounded"
                          title="Delete Deck"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* Remaining Decks Editorial Grid */}
                {filteredDecks.length > 1 && (
                  <div>
                    <div className="text-xs font-mono uppercase tracking-widest text-[#A8A29E] mb-6 border-b border-[#36332E]/40 pb-2">
                      Additional Decks ({filteredDecks.length - 1})
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-10 gap-y-10">
                      {filteredDecks.slice(1).map((deck) => (
                        <div
                          key={deck.id}
                          className="group border-b border-[#36332E]/60 pb-6 flex flex-col justify-between space-y-4"
                        >
                          <div className="space-y-3">
                            <div className="flex items-center justify-between text-xs font-mono">
                              <span className="text-[#E5B842] uppercase tracking-widest text-[10px] font-bold">
                                {deck.category.replace('_', ' ')}
                              </span>
                              <span className="text-[#A8A29E] text-[11px] font-mono">{deck.date}</span>
                            </div>

                            <h3 className="font-serif-title text-2xl font-bold text-[#FAF7F2] group-hover:text-[#E5B842] transition-colors leading-snug cursor-pointer" onClick={() => setActiveLiveDeck(deck)}>
                              {deck.title}
                            </h3>

                            <div className="text-xs text-[#A8A29E] flex items-center gap-3 font-serif italic">
                              <span>{deck.slides.length} Slides</span>
                              <span>•</span>
                              <span className="not-italic font-mono text-[10px] uppercase text-[#A8A29E]">
                                {deck.aspectRatio}
                              </span>
                            </div>

                            {deck.slides[0] && (
                              <div className="pt-2 text-xs text-[#D6D1C7] font-serif line-clamp-2 border-t border-[#36332E]/30 italic">
                                "{deck.slides[0].bodyText || deck.slides[0].title}"
                              </div>
                            )}
                          </div>

                          <div className="flex items-center justify-between pt-3 border-t border-[#36332E]/30">
                            <button
                              type="button"
                              onClick={() => setActiveLiveDeck(deck)}
                              className="bg-emerald-800/80 hover:bg-emerald-700 text-white font-mono uppercase tracking-wider text-[10px] font-bold px-3 py-1.5 rounded transition-all flex items-center gap-1.5"
                            >
                              <Radio className="w-3 h-3 animate-pulse text-emerald-300" />
                              <span>Go Live</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => onDeleteDeck(deck.id)}
                              className="text-[#A8A29E] hover:text-rose-400 text-xs font-mono transition-colors"
                              title="Delete Deck"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

              </div>
            )}
          </div>
        )}

        {/* TAB 2: MEDIA VAULT */}
        {activeTab === 'MEDIA' && (
          <div className="space-y-10">
            <div className="flex flex-col md:flex-row items-start md:items-end justify-between gap-6 border-b border-[#36332E]/60 pb-8">
              <div className="space-y-2 max-w-xl">
                <div className="text-xs font-mono uppercase tracking-widest text-[#E5B842] flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-[#E5B842] rounded-full inline-block" />
                  Sanctuary Asset Archive
                </div>
                <h2 className="font-serif-title text-4xl font-bold text-[#FAF7F2] tracking-tight">
                  Branch Media Vault
                </h2>
                <p className="text-sm text-[#A8A29E] font-serif italic leading-relaxed">
                  Motion graphics, video loops, and lower thirds bound exclusively to branch <strong className="text-[#E5B842] font-mono not-italic">{session.branch.orgCode}</strong>.
                </p>
              </div>

              <div className="flex items-center gap-4 w-full md:w-auto">
                <div className="relative flex-1 md:w-64">
                  <Search className="w-4 h-4 absolute left-0 top-1/2 -translate-y-1/2 text-[#A8A29E]" />
                  <input
                    type="text"
                    value={mediaSearch}
                    onChange={(e) => setMediaSearch(e.target.value)}
                    placeholder="Search by tag..."
                    className="w-full bg-transparent border-b border-[#36332E] focus:border-[#C59B27] pl-6 pr-2 py-2 text-xs text-[#EFECE6] placeholder-[#575249] focus:outline-none transition-colors font-serif"
                  />
                </div>

                <button
                  type="button"
                  onClick={() => setShowUploadModal(true)}
                  className="bg-[#C59B27] hover:bg-[#E5B842] text-[#171614] font-mono uppercase tracking-widest font-bold px-5 py-2.5 rounded text-xs transition-all flex items-center gap-2 shrink-0 shadow-sm"
                >
                  <Upload className="w-4 h-4" />
                  <span>Upload Media</span>
                </button>
              </div>
            </div>

            {/* Media Gallery Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-10 gap-y-12">
              {filteredMedia.map((asset) => (
                <div
                  key={asset.id}
                  className="group space-y-4 border-b border-[#36332E]/60 pb-6"
                >
                  {/* Aspect Ratio Image Frame */}
                  <div className="aspect-video bg-[#171614] border border-[#36332E]/60 relative overflow-hidden rounded-sm">
                    <img
                      src={asset.thumbnailUrl}
                      alt={asset.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90 group-hover:opacity-100"
                    />
                    <div className="absolute top-2 left-2 bg-[#171614]/90 text-[#E5B842] border border-[#C59B27]/30 px-2 py-0.5 rounded text-[9px] font-mono font-bold uppercase tracking-wider">
                      {asset.type.replace('_', ' ')}
                    </div>
                  </div>

                  {/* Editorial Captions */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <h4 className="font-serif-title font-bold text-lg text-[#FAF7F2] truncate">{asset.name}</h4>
                      <span className="font-mono text-[#A8A29E] text-[10px]">{asset.fileSizeMb} MB</span>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      {asset.tags.map((tag, tIdx) => (
                        <span
                          key={tIdx}
                          className="text-[#E5B842] text-[10px] font-mono"
                        >
                          #{tag}
                        </span>
                      ))}
                    </div>

                    <div className="flex items-center justify-between text-xs text-[#A8A29E] font-serif italic pt-2 border-t border-[#36332E]/30">
                      <span>By {asset.uploadedBy} • {asset.uploadedAt}</span>
                      <button
                        onClick={() => onDeleteMedia(asset.id)}
                        className="text-[#A8A29E] hover:text-rose-400 text-xs font-mono transition-colors"
                        title="Remove Media"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: BRANCH TEAM */}
        {activeTab === 'TEAM' && (
          <div className="space-y-10">
            <div className="flex flex-col md:flex-row items-start md:items-end justify-between gap-6 border-b border-[#36332E]/60 pb-8">
              <div className="space-y-2 max-w-xl">
                <div className="text-xs font-mono uppercase tracking-widest text-[#E5B842] flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-[#E5B842] rounded-full inline-block" />
                  Sanctuary Personnel Ledger
                </div>
                <h2 className="font-serif-title text-4xl font-bold text-[#FAF7F2] tracking-tight">
                  Branch Team & Operators
                </h2>
                <p className="text-sm text-[#A8A29E] font-serif italic leading-relaxed">
                  Authorized operators and directors bound to branch Org Code <strong className="text-[#E5B842] font-mono not-italic">{session.branch.orgCode}</strong>.
                </p>
              </div>

              <button
                onClick={() => setShowAddTeamModal(true)}
                className="bg-[#C59B27] hover:bg-[#E5B842] text-[#171614] font-mono uppercase tracking-widest font-bold px-5 py-2.5 rounded text-xs transition-all shadow-sm flex items-center gap-2 shrink-0"
              >
                <UserPlus className="w-4 h-4" />
                <span>Add Member</span>
              </button>
            </div>

            {/* Add Team Member Form */}
            {showAddTeamModal && (
              <form onSubmit={handleAddTeamSubmit} className="border-y border-[#C59B27]/40 py-8 my-6 space-y-6 max-w-2xl bg-[#171614]">
                <h3 className="font-serif-title text-xl font-bold text-[#FAF7F2] flex items-center gap-2">
                  <UserPlus className="w-4 h-4 text-[#E5B842]" />
                  Invite New Branch Operator
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-xs font-mono uppercase tracking-wider text-[#D6D1C7] mb-1 font-bold">Full Name *</label>
                    <input
                      type="text"
                      value={newTeamName}
                      onChange={(e) => setNewTeamName(e.target.value)}
                      placeholder="e.g. Sister Maria Vance"
                      required
                      className="w-full bg-[#171614] border-b border-[#36332E] focus:border-[#C59B27] py-2 text-sm text-[#EFECE6] font-serif"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-mono uppercase tracking-wider text-[#D6D1C7] mb-1 font-bold">Email Address *</label>
                    <input
                      type="email"
                      value={newTeamEmail}
                      onChange={(e) => setNewTeamEmail(e.target.value)}
                      placeholder="e.g. maria@gracecentral.org"
                      required
                      className="w-full bg-[#171614] border-b border-[#36332E] focus:border-[#C59B27] py-2 text-sm text-[#EFECE6] font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-[#D6D1C7] mb-1 font-bold">Assigned Role</label>
                  <select
                    value={newTeamRole}
                    onChange={(e) => setNewTeamRole(e.target.value as any)}
                    className="w-full bg-[#171614] border-b border-[#36332E] py-2 text-sm text-[#EFECE6] font-serif"
                  >
                    <option value="WORSHIP_DIRECTOR">Worship Director (Decks & Lyrics)</option>
                    <option value="MEDIA_OPERATOR">Media Operator (Live Presenter & Videos)</option>
                    <option value="VOLUNTEER">Volunteer Assistant (Read Only)</option>
                  </select>
                </div>

                <div className="flex justify-end gap-4 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowAddTeamModal(false)}
                    className="px-4 py-2 text-xs text-[#A8A29E] font-mono uppercase hover:text-[#EFECE6]"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="bg-[#C59B27] hover:bg-[#E5B842] text-[#171614] font-mono uppercase font-bold px-5 py-2 rounded text-xs"
                  >
                    Save & Invite
                  </button>
                </div>
              </form>
            )}

            {/* Team Editorial Ledger */}
            <div>
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-[#36332E] text-[11px] font-mono text-[#E5B842] uppercase tracking-widest">
                    <th className="py-4 px-2 font-bold">Member Name</th>
                    <th className="py-4 px-2 font-bold">Email Address</th>
                    <th className="py-4 px-2 font-bold">Assigned Role</th>
                    <th className="py-4 px-2 font-bold">Branch Access</th>
                    <th className="py-4 px-2 font-bold">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#36332E]/40 text-sm">
                  {teamMembers.map((member) => (
                    <tr key={member.id} className="hover:bg-[#1F1D1A]/50 transition-colors">
                      <td className="py-4 px-2 font-serif font-bold text-[#FAF7F2] text-base">
                        {member.name}
                      </td>
                      <td className="py-4 px-2 text-[#A8A29E] font-mono text-xs">{member.email}</td>
                      <td className="py-4 px-2 font-serif font-semibold text-[#E5B842]">
                        {member.role.replace('_', ' ')}
                      </td>
                      <td className="py-4 px-2 font-mono text-emerald-400 text-xs">
                        {session.branch.orgCode}
                      </td>
                      <td className="py-4 px-2 font-mono text-[10px] text-emerald-400 uppercase tracking-wider">
                        ● {member.status}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 4: TENANT SECURITY & AUDIT */}
        {activeTab === 'SECURITY' && (
          <div className="space-y-10">
            <div className="border-b border-[#36332E]/60 pb-8 space-y-2 max-w-xl">
              <div className="text-xs font-mono uppercase tracking-widest text-[#E5B842] flex items-center gap-2">
                <span className="w-1.5 h-1.5 bg-[#E5B842] rounded-full inline-block" />
                Security Audit Digest
              </div>
              <h2 className="font-serif-title text-4xl font-bold text-[#FAF7F2] tracking-tight">
                Tenant Data Boundaries
              </h2>
              <p className="text-sm text-[#A8A29E] font-serif italic leading-relaxed">
                Real-time security log confirming media vault isolation for branch Org Code <strong className="text-[#E5B842] font-mono not-italic">{session.branch.orgCode}</strong>.
              </p>
            </div>

            <div className="divide-y divide-[#36332E]/40">
              {auditLogs.map((log) => (
                <div key={log.id} className="py-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="font-serif font-bold text-[#FAF7F2] text-lg flex items-center gap-3">
                      <span>{log.event}</span>
                      <span className="text-emerald-400 font-mono text-[10px] uppercase tracking-wider border border-emerald-800/40 px-2 py-0.5 rounded">
                        {log.status}
                      </span>
                    </div>
                    <div className="text-xs text-[#A8A29E] font-mono flex items-center gap-4">
                      <span>Actor: {log.actorEmail}</span>
                      <span>•</span>
                      <span>IP: {log.ipAddress}</span>
                    </div>
                  </div>
                  <div className="text-xs text-[#A8A29E] font-mono shrink-0">
                    {log.timestamp}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 5: BRANCH SETTINGS & SPECS */}
        {activeTab === 'SETTINGS' && (
          <div className="space-y-10 max-w-3xl">
            <div className="border-b border-[#36332E]/60 pb-8 space-y-2">
              <div className="text-xs font-mono uppercase tracking-widest text-[#E5B842] flex items-center gap-2">
                <span className="w-1.5 h-1.5 bg-[#E5B842] rounded-full inline-block" />
                Branch Metadata & Specifications
              </div>
              <h2 className="font-serif-title text-4xl font-bold text-[#FAF7F2] tracking-tight">
                Sanctuary Specifications
              </h2>
            </div>

            <div className="divide-y divide-[#36332E]/40 text-sm">
              <div className="py-5 flex items-center justify-between">
                <span className="text-[#A8A29E] font-mono uppercase tracking-wider text-xs font-bold">Organization Code (ID)</span>
                <span className="font-mono font-bold text-[#E5B842] text-lg">{session.branch.orgCode}</span>
              </div>

              <div className="py-5 flex items-center justify-between">
                <span className="text-[#A8A29E] font-mono uppercase tracking-wider text-xs font-bold">Church Branch Name</span>
                <span className="font-serif font-bold text-[#FAF7F2] text-lg">{session.branch.name}</span>
              </div>

              <div className="py-5 flex items-center justify-between">
                <span className="text-[#A8A29E] font-mono uppercase tracking-wider text-xs font-bold">Parent Denomination Network</span>
                <span className="font-serif text-[#D6D1C7] text-base">{session.branch.parentOrgName}</span>
              </div>

              <div className="py-5 flex items-center justify-between">
                <span className="text-[#A8A29E] font-mono uppercase tracking-wider text-xs font-bold">Sanctuary Location</span>
                <span className="font-serif text-[#D6D1C7] text-base">{session.branch.location}</span>
              </div>

              <div className="py-5 flex items-center justify-between">
                <span className="text-[#A8A29E] font-mono uppercase tracking-wider text-xs font-bold">Default Projector Ratio</span>
                <span className="font-mono text-[#E5B842] text-base">{session.branch.defaultAspectRatio} Widescreen</span>
              </div>
            </div>
          </div>
        )}

      </main>

      {/* Render Modals */}
      {activeLiveDeck && (
        <LivePresenterModal
          deck={activeLiveDeck}
          session={session}
          onClose={() => setActiveLiveDeck(null)}
        />
      )}

      {showNewDeckModal && (
        <NewDeckModal
          session={session}
          onClose={() => setShowNewDeckModal(false)}
          onCreateDeck={onCreateDeck}
        />
      )}

      {showUploadModal && (
        <MediaUploadModal
          session={session}
          onClose={() => setShowUploadModal(false)}
          onUploadMedia={onUploadMedia}
        />
      )}

    </div>
  );

};
