import React, { useState } from 'react';
import { 
  ShieldCheck, 
  ArrowRight, 
  PlusCircle, 
  LogIn, 
  AlertCircle,
  Tv,
  MapPin
} from 'lucide-react';
import { ChurchBranch, UserSession } from '../types';
import { INITIAL_DEMO_BRANCHES, PARENT_ORGANIZATIONS } from '../data/mockData';
import { OrgCodeBadge } from './OrgCodeBadge';

interface AuthScreenProps {
  branches: ChurchBranch[];
  onLoginSuccess: (session: UserSession) => void;
  onRegisterBranch: (newBranch: ChurchBranch) => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({
  branches,
  onLoginSuccess,
  onRegisterBranch,
}) => {
  const [activeTab, setActiveTab] = useState<'LOGIN' | 'REGISTER'>('LOGIN');

  // Login Form state
  const [loginOrgCode, setLoginOrgCode] = useState('FSQ-3A5HE6');
  const [loginPassword, setLoginPassword] = useState('grace2026');
  const [loginError, setLoginError] = useState('');
  const [isAuthenticating, setIsAuthenticating] = useState(false);

  // Registration Form state
  const [selectedParentId, setSelectedParentId] = useState(PARENT_ORGANIZATIONS[0].id);
  const [regBranchName, setRegBranchName] = useState('');
  const [regStreetAddress, setRegStreetAddress] = useState('');
  const [regCity, setRegCity] = useState('');
  const [regState, setRegState] = useState('');
  const [regPostalCode, setRegPostalCode] = useState('');
  const [regCountry, setRegCountry] = useState('United States');
  const [regAdminName, setRegAdminName] = useState('');
  const [regAdminEmail, setRegAdminEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regRetypePassword, setRegRetypePassword] = useState('');
  const [regError, setRegError] = useState('');
  const [regOrgCodeSuffix, setRegOrgCodeSuffix] = useState('');
  const [regSuccess, setRegSuccess] = useState<ChurchBranch | null>(null);

  // Auto-format Org Code input (e.g. FSQ-3A5HE6)
  const handleOrgCodeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let val = e.target.value.toUpperCase().replace(/[^A-Z0-9-]/g, '');
    if (val.length === 3 && !val.includes('-')) {
      val = val + '-';
    }
    if (val.length > 10) val = val.slice(0, 10);
    setLoginOrgCode(val);
    setLoginError('');
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setIsAuthenticating(true);

    setTimeout(() => {
      const cleanCode = loginOrgCode.trim().toUpperCase();
      const matchedBranch = branches.find(
        (b) => b.orgCode.toUpperCase() === cleanCode
      );

      if (!matchedBranch) {
        setLoginError(`Organization Code "${cleanCode}" not found in Church Directory. Please check your branch ID or use Directory Lookup.`);
        setIsAuthenticating(false);
        return;
      }

      if (matchedBranch.passwordHash !== loginPassword) {
        setLoginError('Invalid password credentials for this branch account.');
        setIsAuthenticating(false);
        return;
      }

      // Login Successful
      const session: UserSession = {
        branch: matchedBranch,
        userEmail: matchedBranch.adminEmail,
        userName: matchedBranch.adminName,
        role: 'BRANCH_ADMIN',
        token: `jwt-token-${matchedBranch.id}-${Date.now()}`,
      };

      setIsAuthenticating(false);
      onLoginSuccess(session);
    }, 600);
  };

  const handleQuickDemoSelect = (branch: ChurchBranch) => {
    setLoginOrgCode(branch.orgCode);
    setLoginPassword(branch.passwordHash);
    setLoginError('');
  };

  // Generate random 6 character code suffix
  const generateRandomSuffix = () => {
    const chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
    let res = '';
    for (let i = 0; i < 6; i++) {
      res += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return res;
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRegError('');

    if (!regBranchName || !regAdminEmail || !regPassword) return;

    if (regPassword !== regRetypePassword) {
      setRegError('Passwords do not match. Please verify your password entry.');
      return;
    }

    const parent = PARENT_ORGANIZATIONS.find((p) => p.id === selectedParentId) || PARENT_ORGANIZATIONS[0];
    const suffix = regOrgCodeSuffix || generateRandomSuffix();
    const generatedOrgCode = `${parent.shortCode}-${suffix.toUpperCase()}`;

    const locationParts = [regStreetAddress, regCity, regState, regPostalCode, regCountry].filter(Boolean);
    const fullLocation = locationParts.join(', ');

    const newBranch: ChurchBranch = {
      id: `branch-${parent.shortCode.toLowerCase()}-${suffix.toLowerCase()}`,
      orgCode: generatedOrgCode,
      name: regBranchName,
      parentOrgId: parent.id,
      parentOrgName: parent.name,
      location: fullLocation || 'Main Campus',
      sanctuaryCapacity: 500,
      defaultAspectRatio: '16:9',
      adminName: regAdminName || 'Branch Administrator',
      adminEmail: regAdminEmail,
      passwordHash: regPassword,
      createdAt: new Date().toISOString().split('T')[0],
      verified: true,
      status: 'ACTIVE',
      storageUsedMb: 120,
      maxStorageMb: 5000,
    };

    onRegisterBranch(newBranch);
    setRegSuccess(newBranch);
  };

  return (
    <div className={`min-h-screen bg-[#171614] text-[#EFECE6] flex flex-col justify-between selection:bg-[#C59B27] selection:text-[#171614] relative font-sans w-full ${activeTab === 'LOGIN' ? 'lg:h-screen lg:overflow-hidden' : 'overflow-y-auto'}`}>
      
      {/* Top Application Editorial Header Bar */}
      <header className="w-full border-b border-[#36332E]/60 bg-[#171614] px-8 py-3.5 flex items-center justify-between z-10 shrink-0">
        <div className="flex items-center gap-4">
          <div className="w-8 h-8 rounded bg-[#C59B27]/10 text-[#E5B842] flex items-center justify-center font-black border border-[#C59B27]/30">
            <Tv className="w-4 h-4 text-[#E5B842]" />
          </div>
          <div>
            <div className="flex items-center gap-3">
              <span className="font-serif-title text-xl font-bold text-[#FAF7F2] tracking-wide">EcclesiaCast</span>
              <span className="text-[10px] font-mono tracking-widest uppercase text-[#E5B842] border border-[#C59B27]/30 px-2 py-0.5 rounded font-semibold">
                Private Branch Network
              </span>
            </div>
            <p className="text-[11px] text-[#A8A29E] font-serif italic hidden sm:block">
              Multi-Tenant Sanctuary Presentation & Media Suite
            </p>
          </div>
        </div>

        <div className="flex items-center gap-5 text-xs text-[#A8A29E]">
          <div className="flex items-center gap-2 font-mono text-emerald-400 text-xs">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Data Isolation Active</span>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 flex items-center justify-center px-8 py-6 z-10 max-w-7xl mx-auto w-full overflow-y-auto lg:overflow-visible">
        <div className="w-full grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-start">
          
          {/* Left Column: Editorial Vision & Security */}
          <div className="lg:col-span-5 space-y-6">
            <div className="space-y-2">
              <div className="text-xs font-mono uppercase tracking-widest text-[#E5B842]">
                Private Network Portal
              </div>

              <h1 className="font-serif-title text-3xl sm:text-4xl font-bold tracking-tight text-[#FAF7F2] leading-[1.15]">
                One Church Network.<br />
                <span className="italic font-serif text-[#E5B842]">
                  Isolated Sanctuary Media.
                </span>
              </h1>
            </div>

            <div className="editorial-rule" />

            <p className="text-[#D6D1C7] text-sm sm:text-base leading-relaxed font-serif">
              EcclesiaCast ensures each church branch operates within its own secure media vault. Log in with your unique <strong className="text-[#E5B842] font-mono font-bold">Organization Code (ID)</strong> and password to stream hymns, scripture slide decks, and sermon graphics safely.
            </p>
          </div>

          {/* Right Column: Flat Editorial Form Panel */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Minimalist Tab Navigation */}
            <div className="flex items-center gap-8 border-b border-[#36332E]/60 pb-3">
              <button
                type="button"
                onClick={() => setActiveTab('LOGIN')}
                className={`py-2 text-xs font-mono uppercase tracking-widest transition-all flex items-center gap-2 border-b-2 ${
                  activeTab === 'LOGIN'
                    ? 'border-[#C59B27] text-[#E5B842] font-bold'
                    : 'border-transparent text-[#A8A29E] hover:text-[#EFECE6]'
                }`}
              >
                <LogIn className="w-4 h-4" />
                <span>Branch Login</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('REGISTER')}
                className={`py-2 text-xs font-mono uppercase tracking-widest transition-all flex items-center gap-2 border-b-2 ${
                  activeTab === 'REGISTER'
                    ? 'border-[#C59B27] text-[#E5B842] font-bold'
                    : 'border-transparent text-[#A8A29E] hover:text-[#EFECE6]'
                }`}
              >
                <PlusCircle className="w-4 h-4" />
                <span>Onboard Branch</span>
              </button>
            </div>

            {/* TAB 1: BRANCH LOGIN */}
            {activeTab === 'LOGIN' && (
              <form onSubmit={handleLoginSubmit} className="space-y-5">
                <div className="space-y-1">
                  <h2 className="font-serif-title text-2xl sm:text-3xl font-bold text-[#FAF7F2]">
                    Sanctuary Access
                  </h2>
                  <p className="text-xs sm:text-sm text-[#A8A29E] font-serif italic">
                    Provide your assigned Organization Code (ID) and Password to open your media vault.
                  </p>
                </div>

                {loginError && (
                  <div className="py-2 px-3 bg-rose-950/20 border border-rose-800/80 rounded text-rose-300 text-xs flex items-start gap-2.5 my-1">
                    <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-bold text-rose-300 font-mono uppercase text-[10px] tracking-wider">Authentication Error</p>
                      <p className="mt-0.5 leading-normal font-serif italic text-xs sm:text-sm">{loginError}</p>
                    </div>
                  </div>
                )}

                {/* Field 1: Organization Code (ID) */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-mono uppercase tracking-widest text-[#E5B842] font-bold">
                    <span>Branch Organization Code (ID) *</span>
                  </label>
                  <input
                    type="text"
                    value={loginOrgCode}
                    onChange={handleOrgCodeChange}
                    placeholder="e.g. FSQ-3A5HE6"
                    required
                    className="w-full bg-[#171614] border-b border-[#C59B27] py-1.5 text-[#E5B842] font-mono text-xl tracking-widest font-bold placeholder-[#575249] focus:outline-none focus:border-[#E5B842] uppercase transition-colors"
                  />
                  <p className="text-xs text-[#A8A29E] font-serif italic">
                    Valid Code Formats: <span className="font-mono text-[#E5B842] not-italic">FSQ-3A5HE6</span>, <span className="font-mono text-[#E5B842] not-italic">RCC-9X2K4L</span>, <span className="font-mono text-[#E5B842] not-italic">GLC-4M8P1Z</span>
                  </p>
                </div>

                {/* Field 2: Password */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-mono uppercase tracking-widest text-[#D6D1C7] font-bold">
                    Branch Security Password *
                  </label>
                  <input
                    type="password"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="••••••••••••"
                    required
                    className="w-full bg-[#171614] border-b border-[#36332E] py-1.5 text-[#EFECE6] text-sm placeholder-[#575249] focus:outline-none focus:border-[#C59B27] transition-colors"
                  />
                </div>

                {/* Submit Button */}
                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={isAuthenticating}
                    className="bg-[#C59B27] hover:bg-[#E5B842] text-[#171614] font-mono uppercase tracking-wider font-extrabold py-3.5 px-8 rounded text-xs transition-all shadow-sm flex items-center justify-center gap-3 disabled:opacity-50"
                  >
                    {isAuthenticating ? (
                      <>
                        <div className="w-4 h-4 border-2 border-[#171614] border-t-transparent rounded-full animate-spin" />
                        <span>Verifying Credentials...</span>
                      </>
                    ) : (
                      <>
                        <ShieldCheck className="w-4 h-4" />
                        <span>Open Sanctuary Media Vault</span>
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}

            {/* TAB 2: ONBOARD NEW BRANCH */}
            {activeTab === 'REGISTER' && (
              <div>
                {regSuccess ? (
                  <div className="py-6 space-y-6">
                    <div className="space-y-2">
                      <div className="text-xs font-mono uppercase tracking-widest text-emerald-400">Confirmation Success</div>
                      <h3 className="font-serif-title text-3xl font-bold text-[#FAF7F2]">
                        Branch Onboarded
                      </h3>
                      <p className="text-sm text-[#A8A29E] font-serif italic">
                        Your church branch has been assigned a unique multi-tenant Organization Code. Keep this code safe for all team logins.
                      </p>
                    </div>

                    <div className="border-y border-[#C59B27]/40 py-6 space-y-3">
                      <div className="text-xs text-[#A8A29E] font-mono uppercase tracking-wider">Assigned Organization Code:</div>
                      <OrgCodeBadge code={regSuccess.orgCode} size="lg" />
                      
                      <div className="pt-3 text-xs space-y-1 text-[#D6D1C7] font-serif">
                        <div><strong>Branch Name:</strong> {regSuccess.name}</div>
                        <div><strong>Parent Network:</strong> {regSuccess.parentOrgName}</div>
                        <div><strong>Location:</strong> {regSuccess.location}</div>
                        <div><strong>Admin Email:</strong> {regSuccess.adminEmail}</div>
                      </div>
                    </div>

                    <div>
                      <button
                        type="button"
                        onClick={() => {
                          setLoginOrgCode(regSuccess.orgCode);
                          setLoginPassword(regSuccess.passwordHash);
                          setActiveTab('LOGIN');
                          setRegSuccess(null);
                        }}
                        className="bg-[#C59B27] hover:bg-[#E5B842] text-[#171614] font-mono uppercase font-bold px-6 py-3 rounded text-xs transition-all inline-flex items-center gap-2"
                      >
                        <span>Proceed to Branch Login</span>
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ) : (
                  <form onSubmit={handleRegisterSubmit} className="space-y-6">
                    <div className="space-y-1">
                      <h2 className="font-serif-title text-3xl font-bold text-[#FAF7F2]">
                        Branch Onboarding
                      </h2>
                      <p className="text-sm text-[#A8A29E] font-serif italic">
                        Register your church location under an authorized parent denomination network.
                      </p>
                    </div>

                    {regError && (
                      <div className="py-3 text-rose-300 text-xs flex items-start gap-2.5 border-y border-rose-800/80 my-2">
                        <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                        <div>
                          <p className="font-bold text-rose-300 font-mono uppercase text-[10px] tracking-wider">Registration Error</p>
                          <p className="mt-0.5 leading-normal font-serif italic text-sm">{regError}</p>
                        </div>
                      </div>
                    )}

                    {/* Parent Selector */}
                    <div className="space-y-2">
                      <label className="block text-xs font-mono uppercase tracking-widest text-[#E5B842] font-bold">
                        Parent Denomination / Network *
                      </label>
                      <select
                        value={selectedParentId}
                        onChange={(e) => setSelectedParentId(e.target.value)}
                        className="w-full bg-[#171614] border-b border-[#36332E] py-2 text-[#EFECE6] text-sm focus:outline-none focus:border-[#C59B27] font-serif"
                      >
                        {PARENT_ORGANIZATIONS.map((parent) => (
                          <option key={parent.id} value={parent.id}>
                            {parent.name} ({parent.shortCode}) — {parent.totalBranches} Active Branches
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Branch Name */}
                    <div className="space-y-2">
                      <label className="block text-xs font-mono uppercase tracking-widest text-[#D6D1C7] font-bold">
                        Branch / Campus Name *
                      </label>
                      <input
                        type="text"
                        value={regBranchName}
                        onChange={(e) => setRegBranchName(e.target.value)}
                        placeholder="e.g. Grace Chapel West"
                        required
                        className="w-full bg-[#171614] border-b border-[#36332E] py-2 text-[#EFECE6] text-sm placeholder-[#575249] focus:outline-none focus:border-[#C59B27] font-serif"
                      />
                    </div>

                    {/* Location Breakdown Fields */}
                    <div className="space-y-4 pt-2">
                      <div className="text-xs font-mono uppercase tracking-widest text-[#E5B842] font-bold flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-[#C59B27]" />
                        <span>Branch Location Details</span>
                      </div>

                      <div className="space-y-2">
                        <label className="block text-xs font-mono uppercase tracking-widest text-[#D6D1C7]">
                          Street Address
                        </label>
                        <input
                          type="text"
                          value={regStreetAddress}
                          onChange={(e) => setRegStreetAddress(e.target.value)}
                          placeholder="e.g. 1200 Sanctuary Way"
                          className="w-full bg-[#171614] border-b border-[#36332E] py-2 text-[#EFECE6] text-sm placeholder-[#575249] focus:outline-none focus:border-[#C59B27] font-serif"
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label className="block text-xs font-mono uppercase tracking-widest text-[#D6D1C7]">
                            City *
                          </label>
                          <input
                            type="text"
                            value={regCity}
                            onChange={(e) => setRegCity(e.target.value)}
                            placeholder="e.g. Seattle"
                            required
                            className="w-full bg-[#171614] border-b border-[#36332E] py-2 text-[#EFECE6] text-sm placeholder-[#575249] focus:outline-none focus:border-[#C59B27] font-serif"
                          />
                        </div>

                        <div className="space-y-2">
                          <label className="block text-xs font-mono uppercase tracking-widest text-[#D6D1C7]">
                            State / Province *
                          </label>
                          <input
                            type="text"
                            value={regState}
                            onChange={(e) => setRegState(e.target.value)}
                            placeholder="e.g. WA"
                            required
                            className="w-full bg-[#171614] border-b border-[#36332E] py-2 text-[#EFECE6] text-sm placeholder-[#575249] focus:outline-none focus:border-[#C59B27] font-serif"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label className="block text-xs font-mono uppercase tracking-widest text-[#D6D1C7]">
                            Postal / Zip Code
                          </label>
                          <input
                            type="text"
                            value={regPostalCode}
                            onChange={(e) => setRegPostalCode(e.target.value)}
                            placeholder="e.g. 98101"
                            className="w-full bg-[#171614] border-b border-[#36332E] py-2 text-[#EFECE6] text-sm placeholder-[#575249] focus:outline-none focus:border-[#C59B27] font-mono"
                          />
                        </div>

                        <div className="space-y-2">
                          <label className="block text-xs font-mono uppercase tracking-widest text-[#D6D1C7]">
                            Country
                          </label>
                          <input
                            type="text"
                            value={regCountry}
                            onChange={(e) => setRegCountry(e.target.value)}
                            placeholder="e.g. United States"
                            className="w-full bg-[#171614] border-b border-[#36332E] py-2 text-[#EFECE6] text-sm placeholder-[#575249] focus:outline-none focus:border-[#C59B27] font-serif"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Admin Name & Email */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2">
                      <div className="space-y-2">
                        <label className="block text-xs font-mono uppercase tracking-widest text-[#D6D1C7] font-bold">
                          Lead Pastor Name
                        </label>
                        <input
                          type="text"
                          value={regAdminName}
                          onChange={(e) => setRegAdminName(e.target.value)}
                          placeholder="e.g. Pastor James Wilson"
                          className="w-full bg-[#171614] border-b border-[#36332E] py-2 text-[#EFECE6] text-sm placeholder-[#575249] focus:outline-none focus:border-[#C59B27] font-serif"
                        />
                      </div>

                      <div className="space-y-2">
                        <label className="block text-xs font-mono uppercase tracking-widest text-[#D6D1C7] font-bold">
                          Admin Login Email *
                        </label>
                        <input
                          type="email"
                          value={regAdminEmail}
                          onChange={(e) => setRegAdminEmail(e.target.value)}
                          placeholder="e.g. admin@westchapel.org"
                          required
                          className="w-full bg-[#171614] border-b border-[#36332E] py-2 text-[#EFECE6] text-sm placeholder-[#575249] focus:outline-none focus:border-[#C59B27] font-mono"
                        />
                      </div>
                    </div>

                    {/* Password & Retype Password */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="block text-xs font-mono uppercase tracking-widest text-[#D6D1C7] font-bold">
                          Security Password *
                        </label>
                        <input
                          type="password"
                          value={regPassword}
                          onChange={(e) => {
                            setRegPassword(e.target.value);
                            setRegError('');
                          }}
                          placeholder="Set password"
                          required
                          className="w-full bg-[#171614] border-b border-[#36332E] py-2 text-[#EFECE6] text-sm focus:outline-none focus:border-[#C59B27]"
                        />
                      </div>

                      <div className="space-y-2">
                        <label className="block text-xs font-mono uppercase tracking-widest text-[#D6D1C7] font-bold">
                          Retype Password *
                        </label>
                        <input
                          type="password"
                          value={regRetypePassword}
                          onChange={(e) => {
                            setRegRetypePassword(e.target.value);
                            setRegError('');
                          }}
                          placeholder="Confirm password"
                          required
                          className="w-full bg-[#171614] border-b border-[#36332E] py-2 text-[#EFECE6] text-sm focus:outline-none focus:border-[#C59B27]"
                        />
                      </div>
                    </div>

                    {/* Live Preview of Code */}
                    <div className="border-t border-[#36332E]/60 pt-4 flex items-center justify-between">
                      <div>
                        <div className="text-[10px] font-mono text-[#A8A29E] uppercase tracking-wider">Generated Code Preview:</div>
                        <div className="text-lg font-mono font-bold text-[#E5B842]">
                          {PARENT_ORGANIZATIONS.find((p) => p.id === selectedParentId)?.shortCode}-
                          {regOrgCodeSuffix ? regOrgCodeSuffix.toUpperCase() : 'AUTO-GEN'}
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => setRegOrgCodeSuffix(generateRandomSuffix())}
                        className="text-xs text-[#E5B842] border-b border-[#C59B27] hover:border-[#E5B842] font-mono uppercase"
                      >
                        Regenerate
                      </button>
                    </div>

                    <button
                      type="submit"
                      className="bg-[#C59B27] hover:bg-[#E5B842] text-[#171614] font-mono uppercase font-bold py-3.5 px-8 rounded text-xs transition-all shadow-sm flex items-center justify-center gap-2 mt-2"
                    >
                      <ShieldCheck className="w-4 h-4" />
                      <span>Complete Onboarding</span>
                    </button>
                  </form>
                )}
              </div>
            )}

          </div>

        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-[#36332E]/60 bg-[#171614] px-8 py-3.5 text-xs text-[#A8A29E] z-10 flex flex-col sm:flex-row items-center justify-between gap-4 max-w-7xl mx-auto w-full font-serif shrink-0">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>EcclesiaCast Multi-Tenant Architecture &copy; 2026. Private Network Isolation.</span>
        </div>
        <div className="flex items-center gap-4 text-[#A8A29E] font-mono text-[11px]">
          <span>Encrypted Session Vault</span>
          <span>•</span>
          <span>1920x1080 Sanctuary Presentation Frame</span>
        </div>
      </footer>
    </div>
  );
};
