import React, { useState } from 'react';
import { ShieldCheck, Copy, Check, Building2 } from 'lucide-react';

interface OrgCodeBadgeProps {
  code: string;
  parentOrgName?: string;
  size?: 'sm' | 'md' | 'lg';
  showSecurityTag?: boolean;
}

export const OrgCodeBadge: React.FC<OrgCodeBadgeProps> = ({
  code,
  parentOrgName,
  size = 'md',
  showSecurityTag = true,
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const sizeClasses = {
    sm: 'text-xs px-2.5 py-1 gap-1.5',
    md: 'text-sm px-3.5 py-1.5 gap-2',
    lg: 'text-base px-4 py-2 gap-2.5',
  };

  return (
    <div className="inline-flex items-center gap-2">
      <div
        className={`inline-flex items-center rounded-md font-mono font-bold tracking-widest bg-[#1F1D1A] text-[#E5B842] border border-[#C59B27]/30 shadow-sm group hover:border-[#C59B27]/70 transition-all ${sizeClasses[size]}`}
        title="Unique Multi-Tenant Church Branch Identifier"
      >
        <Building2 className="w-3.5 h-3.5 text-[#C59B27] group-hover:text-[#E5B842]" />
        <span className="select-all tracking-wider font-mono">{code}</span>
        <button
          onClick={handleCopy}
          type="button"
          className="ml-1 p-0.5 hover:bg-[#C59B27]/20 rounded text-[#E5B842]/80 hover:text-[#E5B842] transition-colors"
          title="Copy Organization Code"
        >
          {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
        </button>
      </div>

      {showSecurityTag && (
        <div className="hidden sm:inline-flex items-center gap-1 text-[10px] font-mono uppercase tracking-widest text-emerald-400/90 bg-emerald-950/40 border border-emerald-800/30 px-2 py-0.5 rounded">
          <ShieldCheck className="w-3 h-3 text-emerald-400" />
          <span>Isolated Tenant</span>
        </div>
      )}
    </div>
  );
};

