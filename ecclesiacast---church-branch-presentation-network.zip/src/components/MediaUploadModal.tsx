import React, { useState } from 'react';
import { X, Upload, Image, Film, FileText, CheckCircle2, ShieldCheck, Tag } from 'lucide-react';
import { MediaAsset, UserSession } from '../types';

interface MediaUploadModalProps {
  session: UserSession;
  onClose: () => void;
  onUploadMedia: (newAsset: MediaAsset) => void;
}

export const MediaUploadModal: React.FC<MediaUploadModalProps> = ({
  session,
  onClose,
  onUploadMedia,
}) => {
  const [assetName, setAssetName] = useState('');
  const [mediaType, setMediaType] = useState<MediaAsset['type']>('MOTION_BACKGROUND');
  const [tagInput, setTagInput] = useState('Worship, Background, 4K');
  const [fileSize, setFileSize] = useState('24.5');
  const [samplePresetUrl, setSamplePresetUrl] = useState(
    'https://images.unsplash.com/photo-1519817650390-64a93db51149?q=80&w=1200&auto=format&fit=crop'
  );
  const [isSimulatingUpload, setIsSimulatingUpload] = useState(false);
  const [uploadedSuccess, setUploadedSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!assetName.trim()) return;

    setIsSimulatingUpload(true);

    setTimeout(() => {
      const tagsArray = tagInput.split(',').map((t) => t.trim()).filter(Boolean);

      const newAsset: MediaAsset = {
        id: `media-${session.branch.id}-${Date.now()}`,
        branchId: session.branch.id,
        name: assetName,
        type: mediaType,
        url: samplePresetUrl,
        thumbnailUrl: samplePresetUrl,
        fileSizeMb: parseFloat(fileSize) || 15.0,
        uploadedAt: new Date().toISOString().split('T')[0],
        uploadedBy: session.userName,
        tags: tagsArray,
      };

      setIsSimulatingUpload(false);
      setUploadedSuccess(true);
      onUploadMedia(newAsset);

      setTimeout(() => {
        onClose();
      }, 1000);
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#171614]/85 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#1F1D1A] border border-[#36332E] rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl animate-fadeIn">
        
        {/* Header */}
        <div className="bg-[#171614] px-6 py-4 border-b border-[#36332E] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-[#C59B27]/10 text-[#E5B842] rounded border border-[#C59B27]/20">
              <Upload className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-serif-title font-bold text-[#FAF7F2]">Upload Branch Media Asset</h3>
              <p className="text-xs text-[#A8A29E] font-mono">
                Tenant Isolation: <span className="text-[#E5B842]">{session.branch.orgCode}</span>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-[#A8A29E] hover:text-[#FAF7F2] rounded hover:bg-[#2A2723] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        {uploadedSuccess ? (
          <div className="p-8 text-center space-y-3">
            <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
            <h4 className="text-lg font-serif-title font-bold text-[#FAF7F2]">Asset Uploaded & Encrypted!</h4>
            <p className="text-xs text-[#A8A29E] font-serif italic">
              Media asset bound exclusively to Organization Code {session.branch.orgCode}.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            
            {/* Drag Drop Zone */}
            <div className="border-2 border-dashed border-[#36332E] hover:border-[#C59B27] bg-[#171614]/60 p-6 rounded-2xl text-center space-y-2 cursor-pointer transition-colors group">
              <Film className="w-8 h-8 text-[#A8A29E] group-hover:text-[#E5B842] mx-auto transition-colors" />
              <div className="text-xs font-serif font-bold text-[#FAF7F2]">
                Drag and drop motion background or graphic here
              </div>
              <div className="text-[11px] text-[#A8A29E] font-serif italic">
                Supports MP4 4K loops, PNG Lower Thirds, JPG Sermon graphics (Max 500MB)
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-mono font-bold uppercase tracking-wider text-[#D6D1C7]">
                Asset Name *
              </label>
              <input
                type="text"
                value={assetName}
                onChange={(e) => setAssetName(e.target.value)}
                placeholder="e.g. Celestial Cross Motion Loop 4K"
                required
                className="w-full bg-[#171614] border border-[#36332E] rounded-xl px-4 py-2.5 text-sm text-[#EFECE6] placeholder-[#575249] focus:outline-none focus:border-[#C59B27] transition-colors font-serif"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <label className="block text-xs font-mono font-bold uppercase tracking-wider text-[#D6D1C7]">
                  Asset Category
                </label>
                <select
                  value={mediaType}
                  onChange={(e) => setMediaType(e.target.value as any)}
                  className="w-full bg-[#171614] border border-[#36332E] rounded-xl px-3.5 py-2.5 text-xs text-[#EFECE6] focus:outline-none focus:border-[#C59B27] font-serif"
                >
                  <option value="MOTION_BACKGROUND">Motion Background Loop</option>
                  <option value="SERMON_SERIES">Sermon Series Graphic</option>
                  <option value="LOWER_THIRD">Lower Third Overlay</option>
                  <option value="AUDIO_STEM">Audio Stem / Pad</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-mono font-bold uppercase tracking-wider text-[#D6D1C7]">
                  Search Tags
                </label>
                <input
                  type="text"
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  placeholder="e.g. Worship, Cross, Loop"
                  className="w-full bg-[#171614] border border-[#36332E] rounded-xl px-3.5 py-2.5 text-xs text-[#EFECE6] placeholder-[#575249] focus:outline-none focus:border-[#C59B27] font-mono"
                />
              </div>
            </div>

            <div className="bg-[#171614] p-3 rounded-xl border border-[#36332E] flex items-center justify-between text-xs text-[#A8A29E]">
              <span className="flex items-center gap-1 text-emerald-400 font-mono text-[11px]">
                <ShieldCheck className="w-3.5 h-3.5" />
                Vault Tenant Isolation
              </span>
              <span className="font-mono text-[#E5B842] font-bold">{session.branch.orgCode}</span>
            </div>

            <div className="pt-2 flex items-center justify-end gap-3 border-t border-[#36332E]">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl text-xs font-mono font-semibold text-[#A8A29E] hover:text-[#FAF7F2] hover:bg-[#2A2723] transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSimulatingUpload}
                className="px-5 py-2.5 rounded-xl text-xs font-mono font-bold bg-[#C59B27] hover:bg-[#E5B842] text-[#171614] transition-all shadow flex items-center gap-1.5 disabled:opacity-50"
              >
                {isSimulatingUpload ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-[#171614] border-t-transparent rounded-full animate-spin" />
                    <span>Encrypting & Storing...</span>
                  </>
                ) : (
                  <>
                    <Upload className="w-4 h-4" />
                    <span>Upload to Vault</span>
                  </>
                )}
              </button>
            </div>

          </form>
        )}

      </div>
    </div>
  );
};
