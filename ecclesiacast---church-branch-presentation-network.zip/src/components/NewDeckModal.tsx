import React, { useState } from 'react';
import { X, Plus, Sparkles, BookOpen, Music, Layers, Tv, Check } from 'lucide-react';
import { PresentationDeck, SlideItem, UserSession } from '../types';

interface NewDeckModalProps {
  session: UserSession;
  onClose: () => void;
  onCreateDeck: (newDeck: PresentationDeck) => void;
}

export const NewDeckModal: React.FC<NewDeckModalProps> = ({
  session,
  onClose,
  onCreateDeck,
}) => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<PresentationDeck['category']>('SUNDAY_WORSHIP');
  const [aspectRatio, setAspectRatio] = useState<PresentationDeck['aspectRatio']>('16:9');
  
  // Initial slide presets generator
  const [includeWelcomeSlide, setIncludeWelcomeSlide] = useState(true);
  const [includeScriptureSlide, setIncludeScriptureSlide] = useState(true);
  const [includeHymnSlide, setIncludeHymnSlide] = useState(true);
  const [includeLowerThirdSlide, setIncludeLowerThirdSlide] = useState(true);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const generatedSlides: SlideItem[] = [];

    if (includeWelcomeSlide) {
      generatedSlides.push({
        id: `slide-${Date.now()}-1`,
        type: 'TITLE',
        title: title.toUpperCase(),
        subtitle: `${session.branch.name} — Worship Service`,
        bodyText: 'Welcome to worship! We are glad you joined us today.',
        bgColor: 'from-amber-950 via-slate-900 to-indigo-950',
        textColor: '#FFFFFF',
        alignment: 'center',
        notes: 'Play prelude ambient music during gathering.',
      });
    }

    if (includeScriptureSlide) {
      generatedSlides.push({
        id: `slide-${Date.now()}-2`,
        type: 'SCRIPTURE',
        title: 'PSALM 100:1-3',
        subtitle: 'Scripture Reading',
        bodyText: 'Shout for joy to the LORD, all the earth. Worship the LORD with gladness; come before him with joyful songs.',
        scriptureReference: 'Psalm 100:1-3 (NIV)',
        bgColor: 'from-indigo-950 via-slate-900 to-blue-950',
        textColor: '#FFFFFF',
        alignment: 'center',
        notes: 'Congregational reading led by Worship Leader.',
      });
    }

    if (includeHymnSlide) {
      generatedSlides.push({
        id: `slide-${Date.now()}-3`,
        type: 'HYMN_VERSE',
        title: 'GREAT IS THY FAITHFULNESS',
        subtitle: 'Hymnal Verse 1',
        bodyText: 'Great is Thy faithfulness, O God my Father,\nThere is no shadow of turning with Thee;\nThou changest not, Thy compassions, they fail not;\nAs Thou hast been Thou forever wilt be.',
        bgColor: 'from-purple-950 via-slate-900 to-amber-950/40',
        textColor: '#FEF08A',
        alignment: 'center',
        notes: 'Acoustic intro into full chorus.',
      });
    }

    if (includeLowerThirdSlide) {
      generatedSlides.push({
        id: `slide-${Date.now()}-4`,
        type: 'LOWER_THIRD',
        title: session.branch.adminName,
        subtitle: `Lead Minister — ${session.branch.name}`,
        bodyText: 'Sermon Title: Living by Faith',
        bgColor: 'transparent',
        textColor: '#FFFFFF',
        alignment: 'left',
        notes: 'Trigger lower third graphic overlay during introduction.',
      });
    }

    if (generatedSlides.length === 0) {
      generatedSlides.push({
        id: `slide-${Date.now()}-blank`,
        type: 'TITLE',
        title: title,
        subtitle: session.branch.name,
        bgColor: 'from-slate-900 to-slate-950',
        textColor: '#FFFFFF',
        alignment: 'center',
      });
    }

    const newDeck: PresentationDeck = {
      id: `deck-${session.branch.id}-${Date.now()}`,
      branchId: session.branch.id,
      title: title,
      category: category,
      date: new Date().toISOString().split('T')[0],
      slides: generatedSlides,
      aspectRatio: aspectRatio,
      isLive: false,
      lastEditedBy: session.userName,
    };

    onCreateDeck(newDeck);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#171614]/90 backdrop-blur-md flex items-center justify-center p-6">
      <div className="bg-[#171614] border-y border-[#C59B27]/40 w-full max-w-lg overflow-hidden p-8 space-y-6 shadow-2xl">
        
        {/* Modal Header */}
        <div className="border-b border-[#36332E]/60 pb-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-[#C59B27]/10 text-[#E5B842] border border-[#C59B27]/30">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xl font-serif-title font-bold text-[#FAF7F2]">Create Presentation Deck</h3>
              <p className="text-xs text-[#A8A29E] font-mono mt-0.5">
                Branch Org Code: <span className="text-[#E5B842] font-bold">{session.branch.orgCode}</span>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-[#A8A29E] hover:text-[#FAF7F2] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <form onSubmit={handleSubmit} className="space-y-6">
          
          <div className="space-y-2">
            <label className="block text-xs font-mono uppercase tracking-widest text-[#E5B842] font-bold">
              Deck Title *
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Sunday Service: Walking in Grace"
              required
              className="w-full bg-[#171614] border-b border-[#C59B27] py-2 text-base text-[#EFECE6] placeholder-[#575249] focus:outline-none focus:border-[#E5B842] transition-colors font-serif"
            />
          </div>

          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="block text-xs font-mono uppercase tracking-widest text-[#D6D1C7] font-bold">
                Service Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full bg-[#171614] border-b border-[#36332E] py-2 text-xs text-[#EFECE6] focus:outline-none focus:border-[#C59B27] font-serif"
              >
                <option value="SUNDAY_WORSHIP">Sunday Worship</option>
                <option value="MIDWEEK_STUDY">Midweek Bible Study</option>
                <option value="YOUTH_NIGHT">Youth Gathering</option>
                <option value="SPECIAL_EVENT">Special Revival / Event</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="block text-xs font-mono uppercase tracking-widest text-[#D6D1C7] font-bold">
                Projector Aspect Ratio
              </label>
              <select
                value={aspectRatio}
                onChange={(e) => setAspectRatio(e.target.value as any)}
                className="w-full bg-[#171614] border-b border-[#36332E] py-2 text-xs text-[#EFECE6] focus:outline-none focus:border-[#C59B27] font-mono"
              >
                <option value="16:9">16:9 Widescreen (HD)</option>
                <option value="16:10">16:10 Sanctuary Proj</option>
                <option value="4:3">4:3 Legacy Screen</option>
              </select>
            </div>
          </div>

          {/* Slide Auto-Generator Checkboxes */}
          <div className="space-y-3 pt-2 border-t border-[#36332E]/60">
            <label className="block text-xs font-mono uppercase tracking-widest text-[#E5B842] font-bold flex items-center gap-2">
              <Layers className="w-3.5 h-3.5" />
              Auto-Generate Slide Templates
            </label>

            <div className="grid grid-cols-2 gap-3 text-xs pt-1">
              <label className="flex items-center gap-2 text-[#D6D1C7] cursor-pointer font-serif">
                <input
                  type="checkbox"
                  checked={includeWelcomeSlide}
                  onChange={(e) => setIncludeWelcomeSlide(e.target.checked)}
                  className="bg-[#171614] border-[#36332E] text-[#C59B27] focus:ring-0"
                />
                <span>Welcome Slide</span>
              </label>

              <label className="flex items-center gap-2 text-[#D6D1C7] cursor-pointer font-serif">
                <input
                  type="checkbox"
                  checked={includeScriptureSlide}
                  onChange={(e) => setIncludeScriptureSlide(e.target.checked)}
                  className="bg-[#171614] border-[#36332E] text-[#C59B27] focus:ring-0"
                />
                <span>Scripture Verse</span>
              </label>

              <label className="flex items-center gap-2 text-[#D6D1C7] cursor-pointer font-serif">
                <input
                  type="checkbox"
                  checked={includeHymnSlide}
                  onChange={(e) => setIncludeHymnSlide(e.target.checked)}
                  className="bg-[#171614] border-[#36332E] text-[#C59B27] focus:ring-0"
                />
                <span>Hymn Lyrics</span>
              </label>

              <label className="flex items-center gap-2 text-[#D6D1C7] cursor-pointer font-serif">
                <input
                  type="checkbox"
                  checked={includeLowerThirdSlide}
                  onChange={(e) => setIncludeLowerThirdSlide(e.target.checked)}
                  className="bg-[#171614] border-[#36332E] text-[#C59B27] focus:ring-0"
                />
                <span>Speaker Overlay</span>
              </label>
            </div>
          </div>

          <div className="pt-4 flex items-center justify-end gap-4 border-t border-[#36332E]/60">
            <button
              type="button"
              onClick={onClose}
              className="text-xs font-mono uppercase tracking-wider font-semibold text-[#A8A29E] hover:text-[#FAF7F2] transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-3 text-xs font-mono uppercase tracking-wider font-bold bg-[#C59B27] hover:bg-[#E5B842] text-[#171614] transition-all shadow flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              <span>Generate Deck</span>
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};
