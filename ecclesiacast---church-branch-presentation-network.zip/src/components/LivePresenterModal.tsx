import React, { useState, useEffect } from 'react';
import { 
  X, 
  ChevronLeft, 
  ChevronRight, 
  Play, 
  EyeOff, 
  Maximize2, 
  Sparkles, 
  Tv, 
  Layers, 
  Clock, 
  Volume2, 
  BookOpen, 
  Music, 
  Monitor, 
  Layout, 
  ShieldCheck,
  Radio
} from 'lucide-react';
import { PresentationDeck, SlideItem, UserSession } from '../types';
import { OrgCodeBadge } from './OrgCodeBadge';

interface LivePresenterModalProps {
  deck: PresentationDeck;
  session: UserSession;
  onClose: () => void;
}

export const LivePresenterModal: React.FC<LivePresenterModalProps> = ({
  deck,
  session,
  onClose,
}) => {
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [isBlackout, setIsBlackout] = useState(false);
  const [isClearText, setIsClearText] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date().toLocaleTimeString());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const activeSlide: SlideItem = deck.slides[currentSlideIndex] || deck.slides[0];

  const handleNext = () => {
    if (currentSlideIndex < deck.slides.length - 1) {
      setCurrentSlideIndex(currentSlideIndex + 1);
    }
  };

  const handlePrev = () => {
    if (currentSlideIndex > 0) {
      setCurrentSlideIndex(currentSlideIndex - 1);
    }
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === 'Space') {
        handleNext();
      } else if (e.key === 'ArrowLeft') {
        handlePrev();
      } else if (e.key === 'b' || e.key === 'B') {
        setIsBlackout((prev) => !prev);
      } else if (e.key === 'c' || e.key === 'C') {
        setIsClearText((prev) => !prev);
      } else if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentSlideIndex, deck.slides.length]);

  return (
    <div className="fixed inset-0 z-50 bg-[#171614] text-[#EFECE6] flex flex-col font-sans select-none overflow-hidden selection:bg-[#C59B27] selection:text-[#171614]">
      {/* Top Desktop Control Bar */}
      <header className="bg-[#1F1D1A] border-b border-[#36332E] px-6 py-2.5 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-[10px] font-mono font-bold uppercase text-emerald-400 bg-emerald-950/80 border border-emerald-800/60 px-2.5 py-0.5 rounded flex items-center gap-1">
              <Radio className="w-3 h-3" />
              Sanctuary Broadcast Live
            </span>
          </div>

          <div className="h-4 w-px bg-[#36332E]" />

          <div>
            <div className="text-sm font-serif-title font-bold text-[#FAF7F2] flex items-center gap-2">
              {deck.title}
            </div>
            <div className="text-[11px] text-[#A8A29E] font-serif italic flex items-center gap-2">
              <span>{session.branch.name}</span>
              <span>•</span>
              <span className="font-mono text-[#E5B842] not-italic">Org ID: {session.branch.orgCode}</span>
            </div>
          </div>
        </div>

        {/* Presenter Clock & Quick Controls */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 bg-[#171614] px-3 py-1 rounded border border-[#36332E] text-xs font-mono text-[#D6D1C7]">
            <Clock className="w-3.5 h-3.5 text-[#E5B842]" />
            <span>{currentTime}</span>
          </div>

          <button
            type="button"
            onClick={() => setIsBlackout(!isBlackout)}
            className={`px-3 py-1.5 rounded text-xs font-mono uppercase tracking-wider font-bold transition-all border ${
              isBlackout
                ? 'bg-[#8C3A27] text-white border-rose-500 shadow'
                : 'bg-[#2A2723] hover:bg-[#36332E] text-[#EFECE6] border-[#36332E]'
            }`}
          >
            [B] Blackout
          </button>

          <button
            type="button"
            onClick={() => setIsClearText(!isClearText)}
            className={`px-3 py-1.5 rounded text-xs font-mono uppercase tracking-wider font-bold transition-all border ${
              isClearText
                ? 'bg-[#C59B27] text-[#171614] border-[#E5B842]'
                : 'bg-[#2A2723] hover:bg-[#36332E] text-[#EFECE6] border-[#36332E]'
            }`}
          >
            [C] Clear Text
          </button>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 bg-[#2A2723] hover:bg-rose-950 hover:text-rose-300 rounded transition-colors border border-[#36332E]"
            title="Exit Presenter Mode (Esc)"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Main Sanctuary Live Stage */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden p-4 gap-4 bg-[#171614]">
        
        {/* Left Column: Live Projector Canvas Output */}
        <div className="lg:col-span-8 flex flex-col justify-between space-y-3">
          
          {/* Virtual Projector Frame */}
          <div className="flex-1 bg-[#1F1D1A] border border-[#36332E] rounded-2xl overflow-hidden relative shadow-2xl flex items-center justify-center p-8">
            
            {/* Displaying Blackout or Normal Slide */}
            {isBlackout ? (
              <div className="absolute inset-0 bg-black flex items-center justify-center text-[#575249] font-mono text-sm tracking-widest uppercase">
                • SANCTUARY PROJECTOR BLACKOUT ACTIVE •
              </div>
            ) : (
              <div
                className={`w-full h-full rounded-xl bg-gradient-to-br ${
                  activeSlide.bgColor || 'from-[#2A2723] via-[#1F1D1A] to-[#171614]'
                } p-8 sm:p-12 flex flex-col justify-between relative overflow-hidden transition-all duration-300 shadow-2xl border border-[#36332E]`}
              >
                {/* Background Stained Glass Subtle Glow */}
                <div className="absolute -right-20 -bottom-20 w-80 h-80 bg-[#C59B27]/10 rounded-full blur-3xl pointer-events-none" />

                {/* Top Badge on Slide */}
                <div className="flex items-center justify-between text-xs tracking-widest font-mono text-[#E5B842] uppercase">
                  <span>{activeSlide.type}</span>
                  <span>{session.branch.name}</span>
                </div>

                {/* Main Content */}
                {!isClearText && (
                  <div className={`space-y-4 my-auto text-${activeSlide.alignment || 'center'}`}>
                    {activeSlide.title && (
                      <h1 className="text-3xl sm:text-5xl font-serif-title font-bold text-[#FAF7F2] tracking-tight leading-tight uppercase drop-shadow">
                        {activeSlide.title}
                      </h1>
                    )}

                    {activeSlide.subtitle && (
                      <h3 className="text-lg sm:text-xl font-serif italic text-[#E5B842] tracking-wide">
                        {activeSlide.subtitle}
                      </h3>
                    )}

                    {activeSlide.bodyText && (
                      <p className="text-lg sm:text-2xl font-serif text-[#EFECE6] max-w-3xl mx-auto leading-relaxed whitespace-pre-line drop-shadow">
                        {activeSlide.bodyText}
                      </p>
                    )}

                    {activeSlide.scriptureReference && (
                      <div className="inline-block mt-4 bg-[#171614]/80 border border-[#C59B27]/40 px-5 py-1.5 rounded-full text-[#E5B842] text-sm font-serif italic">
                        {activeSlide.scriptureReference}
                      </div>
                    )}
                  </div>
                )}

                {/* Bottom Footer on Screen */}
                <div className="flex items-center justify-between text-[11px] font-mono text-[#A8A29E]">
                  <span>EcclesiaCast Multi-Tenant Media</span>
                  <span className="text-[#E5B842]">Org Code: {session.branch.orgCode}</span>
                </div>
              </div>
            )}
          </div>

          {/* Navigation Controls */}
          <div className="bg-[#1F1D1A] border border-[#36332E] p-3 rounded-xl flex items-center justify-between">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handlePrev}
                disabled={currentSlideIndex === 0}
                className="px-4 py-2 bg-[#2A2723] hover:bg-[#36332E] disabled:opacity-30 rounded text-xs font-mono font-bold transition-all flex items-center gap-1"
              >
                <ChevronLeft className="w-4 h-4" />
                Previous (←)
              </button>

              <button
                type="button"
                onClick={handleNext}
                disabled={currentSlideIndex === deck.slides.length - 1}
                className="px-5 py-2 bg-[#C59B27] hover:bg-[#E5B842] text-[#171614] disabled:opacity-30 rounded text-xs font-mono font-bold transition-all flex items-center gap-1 shadow"
              >
                <span>Next Slide (→)</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            <div className="text-xs text-[#A8A29E] font-mono font-semibold">
              Slide <span className="text-[#E5B842]">{currentSlideIndex + 1}</span> of {deck.slides.length}
            </div>
          </div>
        </div>

        {/* Right Column: Slide Deck Grid & Presenter Notes */}
        <div className="lg:col-span-4 flex flex-col space-y-4 overflow-hidden">
          
          {/* Speaker Notes Card */}
          <div className="bg-[#1F1D1A] border border-[#36332E] p-4 rounded-xl space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold uppercase tracking-wider text-[#E5B842] flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                Presenter Notes
              </span>
              <span className="text-[10px] font-mono bg-[#171614] px-2 py-0.5 rounded text-[#A8A29E]">
                Confidence Monitor
              </span>
            </div>
            <p className="text-xs text-[#D6D1C7] bg-[#171614] p-3 rounded border border-[#36332E] min-h-[60px] font-serif italic">
              {activeSlide.notes || "No specific notes attached to this slide."}
            </p>
          </div>

          {/* Slide Deck Strip */}
          <div className="flex-1 bg-[#1F1D1A] border border-[#36332E] p-4 rounded-xl flex flex-col overflow-hidden space-y-3">
            <div className="flex items-center justify-between border-b border-[#36332E] pb-2">
              <span className="text-xs font-mono font-bold uppercase tracking-wider text-[#D6D1C7] flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-[#C59B27]" />
                Deck Slide Queue ({deck.slides.length})
              </span>
              <span className="text-[10px] text-[#A8A29E] font-mono">Click to jump</span>
            </div>

            <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
              {deck.slides.map((slide, idx) => (
                <button
                  key={slide.id}
                  type="button"
                  onClick={() => setCurrentSlideIndex(idx)}
                  className={`w-full text-left p-3 rounded-xl border transition-all flex items-start gap-3 ${
                    currentSlideIndex === idx
                      ? 'bg-[#171614] border-[#C59B27] shadow'
                      : 'bg-[#171614]/60 border-[#36332E] hover:border-[#36332E] hover:bg-[#171614]'
                  }`}
                >
                  <span
                    className={`text-xs font-mono font-bold w-6 h-6 rounded flex items-center justify-center shrink-0 ${
                      currentSlideIndex === idx
                        ? 'bg-[#C59B27] text-[#171614]'
                        : 'bg-[#2A2723] text-[#A8A29E]'
                    }`}
                  >
                    {idx + 1}
                  </span>

                  <div className="min-w-0 flex-1 space-y-0.5">
                    <div className="text-xs font-serif font-bold text-[#EFECE6] truncate">
                      {slide.title || 'Untitled Slide'}
                    </div>
                    {slide.bodyText && (
                      <div className="text-[11px] text-[#A8A29E] font-serif truncate">
                        {slide.bodyText}
                      </div>
                    )}
                    <div className="text-[10px] font-mono text-[#A8A29E] uppercase pt-0.5">
                      {slide.type}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Tenant Isolation Footer Tag */}
          <div className="bg-[#171614] border border-[#36332E] p-2.5 rounded flex items-center justify-between text-[11px] text-[#A8A29E]">
            <span className="flex items-center gap-1 text-emerald-400 font-mono text-[11px]">
              <ShieldCheck className="w-3.5 h-3.5" />
              Tenant Isolated Access
            </span>
            <span className="font-mono text-[#E5B842] font-bold">{session.branch.orgCode}</span>
          </div>

        </div>

      </div>
    </div>
  );
};
