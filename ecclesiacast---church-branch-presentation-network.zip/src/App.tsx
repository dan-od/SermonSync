/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ChurchBranch, UserSession, PresentationDeck, MediaAsset, TeamMember, SecurityAuditLog } from './types';
import { INITIAL_DEMO_BRANCHES, INITIAL_DECKS, INITIAL_MEDIA, INITIAL_TEAM, INITIAL_LOGS } from './data/mockData';
import { AuthScreen } from './components/AuthScreen';
import { BranchDashboard } from './components/BranchDashboard';

export default function App() {
  const [branches, setBranches] = useState<ChurchBranch[]>(INITIAL_DEMO_BRANCHES);
  const [activeSession, setActiveSession] = useState<UserSession | null>(null);

  // Tenant-isolated state maps
  const [decksMap, setDecksMap] = useState<Record<string, PresentationDeck[]>>(INITIAL_DECKS);
  const [mediaMap, setMediaMap] = useState<Record<string, MediaAsset[]>>(INITIAL_MEDIA);
  const [teamMap, setTeamMap] = useState<Record<string, TeamMember[]>>(INITIAL_TEAM);
  const [logsMap, setLogsMap] = useState<Record<string, SecurityAuditLog[]>>(INITIAL_LOGS);

  // Handle Login Success
  const handleLoginSuccess = (session: UserSession) => {
    setActiveSession(session);

    // Record login audit event
    const newLog: SecurityAuditLog = {
      id: `log-${Date.now()}`,
      branchId: session.branch.id,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      event: `Branch Logged In via Org Code [${session.branch.orgCode}]`,
      actorEmail: session.userEmail,
      ipAddress: '198.51.100.88',
      status: 'SUCCESS',
    };

    setLogsMap((prev) => ({
      ...prev,
      [session.branch.id]: [newLog, ...(prev[session.branch.id] || [])],
    }));
  };

  // Handle Branch Onboarding Registration
  const handleRegisterBranch = (newBranch: ChurchBranch) => {
    setBranches((prev) => [newBranch, ...prev]);

    // Initialize empty tenant stores
    setDecksMap((prev) => ({ ...prev, [newBranch.id]: [] }));
    setMediaMap((prev) => ({ ...prev, [newBranch.id]: [] }));
    setTeamMap((prev) => ({
      ...prev,
      [newBranch.id]: [
        {
          id: `tm-${newBranch.id}-admin`,
          branchId: newBranch.id,
          name: newBranch.adminName,
          email: newBranch.adminEmail,
          role: 'BRANCH_ADMIN',
          status: 'ACTIVE',
          joinedDate: newBranch.createdAt,
        },
      ],
    }));
    setLogsMap((prev) => ({
      ...prev,
      [newBranch.id]: [
        {
          id: `log-${Date.now()}`,
          branchId: newBranch.id,
          timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
          event: `Branch Account Onboarded & Org Code [${newBranch.orgCode}] Issued`,
          actorEmail: newBranch.adminEmail,
          ipAddress: '198.51.100.12',
          status: 'SUCCESS',
        },
      ],
    }));
  };

  // Handle Logout
  const handleLogout = () => {
    setActiveSession(null);
  };

  // Deck Management (Branch Isolated)
  const handleCreateDeck = (deck: PresentationDeck) => {
    if (!activeSession) return;
    const branchId = activeSession.branch.id;

    setDecksMap((prev) => ({
      ...prev,
      [branchId]: [deck, ...(prev[branchId] || [])],
    }));
  };

  const handleDeleteDeck = (deckId: string) => {
    if (!activeSession) return;
    const branchId = activeSession.branch.id;

    setDecksMap((prev) => ({
      ...prev,
      [branchId]: (prev[branchId] || []).filter((d) => d.id !== deckId),
    }));
  };

  // Media Management (Branch Isolated)
  const handleUploadMedia = (asset: MediaAsset) => {
    if (!activeSession) return;
    const branchId = activeSession.branch.id;

    setMediaMap((prev) => ({
      ...prev,
      [branchId]: [asset, ...(prev[branchId] || [])],
    }));
  };

  const handleDeleteMedia = (mediaId: string) => {
    if (!activeSession) return;
    const branchId = activeSession.branch.id;

    setMediaMap((prev) => ({
      ...prev,
      [branchId]: (prev[branchId] || []).filter((m) => m.id !== mediaId),
    }));
  };

  // Team Management (Branch Isolated)
  const handleAddTeamMember = (member: TeamMember) => {
    if (!activeSession) return;
    const branchId = activeSession.branch.id;

    setTeamMap((prev) => ({
      ...prev,
      [branchId]: [...(prev[branchId] || []), member],
    }));
  };

  // If no active session, display AuthScreen
  if (!activeSession) {
    return (
      <div className="w-full max-w-[1920px] min-h-screen xl:h-[1080px] mx-auto bg-[#171614] flex flex-col relative overflow-x-hidden">
        <AuthScreen
          branches={branches}
          onLoginSuccess={handleLoginSuccess}
          onRegisterBranch={handleRegisterBranch}
        />
      </div>
    );
  }

  // Active Session: Display Desktop Branch Dashboard
  const branchDecks = decksMap[activeSession.branch.id] || [];
  const branchMedia = mediaMap[activeSession.branch.id] || [];
  const branchTeam = teamMap[activeSession.branch.id] || [];
  const branchLogs = logsMap[activeSession.branch.id] || [];

  return (
    <div className="w-full max-w-[1920px] min-h-screen xl:h-[1080px] mx-auto bg-[#171614] flex flex-col relative overflow-x-hidden">
      <BranchDashboard
        session={activeSession}
        decks={branchDecks}
        mediaList={branchMedia}
        teamMembers={branchTeam}
        auditLogs={branchLogs}
        onLogout={handleLogout}
        onCreateDeck={handleCreateDeck}
        onDeleteDeck={handleDeleteDeck}
        onUploadMedia={handleUploadMedia}
        onDeleteMedia={handleDeleteMedia}
        onAddTeamMember={handleAddTeamMember}
      />
    </div>
  );
}
